// Quiet Space account configuration.
// Replace both placeholder values with your Supabase project's URL and public anon key.
// The anon key is intended for browser use ONLY when Row Level Security is enabled.
window.QS_SUPABASE_URL = 'PASTE_YOUR_SUPABASE_PROJECT_URL_HERE';
window.QS_SUPABASE_ANON_KEY = 'PASTE_YOUR_SUPABASE_ANON_KEY_HERE';
