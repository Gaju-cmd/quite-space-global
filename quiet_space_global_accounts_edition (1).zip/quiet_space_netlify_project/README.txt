QUIET SPACE — FOUNDER EDITION WITH GLOBAL ACCOUNTS
Made by GAJU GASANA ♡

WHAT'S INCLUDED
- Polished Quiet Space design and Our Purpose / Mission / Founder / Team page
- Email + password account sign-up and login
- Persistent Supabase login session until the user logs out
- Private per-account cloud storage for the user's Quiet Space data
- Log out button, password reset email flow, and local browser cache
- netlify/functions/chat.js: server-side Gemini AI chat connection
- netlify.toml: Netlify publish/function settings

IMPORTANT: ACCOUNT SETUP IS NOT ACTIVE UNTIL YOU CONNECT SUPABASE
This project is prepared for global multi-user accounts, but you must create a Supabase project and configure it before account login/cloud sync works. Do not publish as fully working accounts until setup and testing are complete.

SETUP ACCOUNTS + CLOUD DATA
1. Create a project at https://supabase.com/ (ask a trusted adult to help review account/privacy settings if needed).
2. In the Supabase project, open Project Settings > API (or API Keys). Copy the Project URL and the public anon/publishable key. NEVER use the service_role/secret key in the website.
3. Edit supabase-config.js and replace PASTE_YOUR_SUPABASE_PROJECT_URL_HERE and PASTE_YOUR_SUPABASE_ANON_KEY_HERE with those two public values.
4. In Supabase, open SQL Editor, create a new query, paste the full contents of supabase-setup.sql, and run it. This creates the private data table and Row Level Security rules so each account can read/write only its own row.
5. In Supabase Authentication > URL Configuration, add your Netlify site URL to the allowed redirect URLs. Use your actual site URL.
6. In Supabase Authentication settings, leave email confirmation enabled for a public launch. New users may need to confirm their email before logging in.
7. Push the whole project folder to the GitHub repository, including index.html, supabase-config.js, supabase-setup.sql, netlify.toml, and netlify/functions/chat.js. Connect that repository to Netlify and deploy.
8. Test with two separate email accounts: each should see a separate onboarding/profile and must not see the other account's entries. Test sign-out and sign-in again. Test on a second device to confirm cloud sync.

DATA + PRIVACY NOTES
- The app's wellness notes, memories, settings, reminders, and other state are stored in the Supabase row for the signed-in account. Supabase is a third-party cloud provider; this is not end-to-end encrypted. Avoid highly sensitive information and review provider privacy terms before public use.
- The browser anon key is not a secret; the SQL Row Level Security policies are essential. Never put a Supabase service_role/secret key in this project.
- Account login is separate from the optional Quiet Notes lock. That extra lock is only a barrier in the interface and is not strong encryption.
- The app's reminder timers depend on the browser being open and should not replace a phone alarm or professional care plan.
- The AI chat sends messages typed into the chat to the AI provider through the Netlify function. Saved notes are not automatically sent to AI.
- The AI is not a doctor, therapist, or emergency service.

GEMINI AI SETUP
The AI chat will NOT work until GEMINI_API_KEY is added as a secret environment variable in Netlify and the full project (including the Netlify Function) is deployed. Never put the Gemini API key in index.html or supabase-config.js. A free quota may be limited and can change.
