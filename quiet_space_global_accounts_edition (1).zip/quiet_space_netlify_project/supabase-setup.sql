-- Run this in Supabase Dashboard > SQL Editor.
-- This table stores one private Quiet Space data object per signed-in account.
create table if not exists public.quiet_space_data (
  user_id uuid primary key references auth.users(id) on delete cascade,
  payload jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

alter table public.quiet_space_data enable row level security;

-- A user can read only their own record.
create policy "Users can read their own Quiet Space data"
on public.quiet_space_data for select
using (auth.uid() = user_id);

-- A user can create only a record belonging to their own account.
create policy "Users can insert their own Quiet Space data"
on public.quiet_space_data for insert
with check (auth.uid() = user_id);

-- A user can update only their own record.
create policy "Users can update their own Quiet Space data"
on public.quiet_space_data for update
using (auth.uid() = user_id)
with check (auth.uid() = user_id);
